# Talismans Resource Pack — Minecraft Java 1.21.11

## Содержимое
- 7 вариантов тотема: vladyki, razrushitelya, straha, garmonii, zavisimosti, kardio, rkn
- 6 кубических магических сфер: smerti, pokoya, domino, zabavy, azarta, leviafana
- Справедливость (порох)
- Светопыль (светокаменная пыль)

## Важно: связь с плагином
Этот архив содержит клиентские текстуры и модели. Чтобы они появились в игре,
плагин должен назначать предметам компонент `minecraft:item_model` со значениями:

- `vladyki`: `talismans:vladyki` (базовый предмет: `minecraft:totem_of_undying`)\n- `razrushitelya`: `talismans:razrushitelya` (базовый предмет: `minecraft:totem_of_undying`)\n- `straha`: `talismans:straha` (базовый предмет: `minecraft:totem_of_undying`)\n- `garmonii`: `talismans:garmonii` (базовый предмет: `minecraft:totem_of_undying`)\n- `zavisimosti`: `talismans:zavisimosti` (базовый предмет: `minecraft:totem_of_undying`)\n- `kardio`: `talismans:kardio` (базовый предмет: `minecraft:totem_of_undying`)\n- `rkn`: `talismans:rkn` (базовый предмет: `minecraft:totem_of_undying`)\n- `smerti`: `talismans:smerti` (базовый предмет: `minecraft:player_head`)\n- `pokoya`: `talismans:pokoya` (базовый предмет: `minecraft:player_head`)\n- `domino`: `talismans:domino` (базовый предмет: `minecraft:player_head`)\n- `zabavy`: `talismans:zabavy` (базовый предмет: `minecraft:player_head`)\n- `azarta`: `talismans:azarta` (базовый предмет: `minecraft:player_head`)\n- `leviafana`: `talismans:leviafana` (базовый предмет: `minecraft:player_head`)\n- `spravedlivost`: `talismans:spravedlivost` (базовый предмет: `minecraft:gunpowder`)\n- `svetopyl`: `talismans:svetopyl` (базовый предмет: `minecraft:glowstone_dust`)\n
Например, предмет «Справедливость» должен быть порохом с компонентом
`minecraft:item_model = talismans:spravedlivost`.

Один только Resource Pack не меняет поведение предметов и не выдаёт их.
Игровую логику (эффекты, GUI, частицы и кулдауны) реализует плагин.

## Установка
1. Поместите ZIP в `.minecraft/resourcepacks` либо распакуйте папку в эту директорию.
2. Включите пакет в меню «Настройки → Наборы ресурсов».
3. Убедитесь, что плагин выдаёт предметам соответствующие `item_model` IDs.

Формат ресурспака: 75 (Minecraft Java 1.21.11).
